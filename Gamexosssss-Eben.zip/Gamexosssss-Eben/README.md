# GameXOSTR

GameXOSTR is being built as a Debian Live-based desktop system. This provides a
real Linux kernel, standard PC hardware support, keyboard and touchpad input,
and a live environment that can be installed to a selected drive.

The current image foundation uses XFCE, Calamares, Wine, Firefox ESR, and
Plymouth. The existing bare-metal kernel files are kept as a small research
target; they are not the kernel used by the desktop ISO.

## Build

On Debian or Ubuntu, install `live-build`, `debootstrap`, `squashfs-tools`,
`xorriso`, `grub-pc-bin`, `grub-efi-amd64-bin`, and `mtools`, then run:

```sh
sudo bash build.sh
```

The build produces `GameXOSTR.iso` in the repository root. GitHub Actions builds
the same image with `build.sh`, checks it with `scripts/verify-iso.sh` (xorriso:
ISO 9660 structure, BIOS and UEFI El Torito entries, live kernel/initrd/SquashFS,
Debian 12 root filesystem) and only then publishes it as the `GameXOSTR-ISO`
artifact. If the build or the verification fails, the workflow fails with the
real log and no artifact is uploaded. Run `make verify` to check a local ISO.

Run `make check` to validate the shell scripts, welcome app syntax, and C source
syntax without installing the ISO build dependencies.

This is an early system foundation, not a finished desktop release. The custom
startup animation, recovery UI, Liquid Glass styling, and GameXOS application
shell still need implementation. Windows application compatibility is provided
through Wine and is not guaranteed for every `.exe` application.
