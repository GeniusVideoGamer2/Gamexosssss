// Installer and partition selector
