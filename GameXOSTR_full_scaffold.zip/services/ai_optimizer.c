// AI optimization service
