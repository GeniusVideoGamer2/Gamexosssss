// Recovery environment
