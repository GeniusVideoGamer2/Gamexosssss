// Hardware detection
